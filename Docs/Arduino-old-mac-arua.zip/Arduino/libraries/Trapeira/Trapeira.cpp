#include "Trapeira.h"

Trapeira::Trapeira():
	state(TRAPEIRA_ENTREABERTA), event(TRAPEIRA_CONSULTAR)
{
}
