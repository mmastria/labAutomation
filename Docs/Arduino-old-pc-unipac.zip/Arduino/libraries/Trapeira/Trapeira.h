#ifndef __TRAPEIRA__
#define __TRAPEIRA__

#include <stddef.h>
#include <avr/pgmspace.h>

typedef enum { TRAPEIRA_ENTREABERTA = 0, TRAPEIRA_FECHADA, TRAPEIRA_ABERTA, TRAPEIRA_FECHANDO, TRAPEIRA_ABRINDO, TRAPEIRA_ERRO } trapeira_state_e;
typedef enum { TRAPEIRA_CONSULTAR = 0, TRAPEIRA_FECHAR, TRAPEIRA_ABRIR } trapeira_event_e;

class Trapeira
{
public:
	Trapeira(void);
	trapeira_state_e state;
	trapeira_event_e event;
};
#endif
